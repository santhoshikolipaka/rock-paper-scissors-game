import random

# What beats a given move, e.g. beats['R'] == 'P' (Paper beats Rock)
beats = {'R': 'P', 'P': 'S', 'S': 'R'}
# What a given move beats, e.g. loses_to['R'] == 'S' (Rock beats Scissors)
loses_to = {'R': 'S', 'P': 'R', 'S': 'P'}


def player(prev_play, opponent_history=[], my_history=[], state={}):
    if not state:
        state.update({
            'ngram_patterns': {},
            'abbey_play_order': {
                "RR": 0, "RP": 0, "RS": 0,
                "PR": 0, "PP": 0, "PS": 0,
                "SR": 0, "SP": 0, "SS": 0,
            },
            'strategy_scores': {'kris': 0, 'abbey': 0, 'mrugesh': 0, 'ngram': 0, 'quincy': 0},
            'strategy_last_guess': {},
            'round': 0,
        })

    if prev_play == "":
        # New match starting - reset all persistent state
        opponent_history.clear()
        my_history.clear()
        state['ngram_patterns'] = {}
        state['abbey_play_order'] = {
            "RR": 0, "RP": 0, "RS": 0,
            "PR": 0, "PP": 0, "PS": 0,
            "SR": 0, "SP": 0, "SS": 0,
        }
        state['strategy_scores'] = {'kris': 0, 'abbey': 0, 'mrugesh': 0, 'ngram': 0, 'quincy': 0}
        state['strategy_last_guess'] = {}
        state['round'] = 0
    else:
        opponent_history.append(prev_play)

        # Score each strategy's previous guess against what actually happened.
        # A guess "wins" if it beats the opponent's actual move, "ties" if
        # it's the same move, and "loses" otherwise.
        for name, guess in state['strategy_last_guess'].items():
            if guess == beats[prev_play]:
                state['strategy_scores'][name] += 1
            elif guess == prev_play:
                state['strategy_scores'][name] += 0
            else:
                state['strategy_scores'][name] -= 1

    state['round'] += 1

    # ---- Update abbey's play_order table using MY move history (abbey's
    # "opponent" is me, so it tracks transitions between my consecutive moves) ----
    if len(my_history) >= 2:
        last_two = "".join(my_history[-2:])
        if last_two in state['abbey_play_order']:
            state['abbey_play_order'][last_two] += 1

    # ---- Update n-gram pattern table from the real opponent's history ----
    n = 4
    if len(opponent_history) > n:
        prev_key = "".join(opponent_history[-(n + 1):-1])
        state['ngram_patterns'].setdefault(prev_key, {'R': 0, 'P': 0, 'S': 0})
        state['ngram_patterns'][prev_key][opponent_history[-1]] += 1

    guesses = {}

    # ---- Simulate kris: kris always plays beats[my_last_move] ----
    if my_history:
        kris_move = beats[my_history[-1]]
        guesses['kris'] = beats[kris_move]
    else:
        guesses['kris'] = random.choice(['R', 'P', 'S'])

    # ---- Simulate abbey ----
    if my_history:
        prev_my_move = my_history[-1]
        potential_plays = [prev_my_move + m for m in ['R', 'P', 'S']]
        sub_order = {k: state['abbey_play_order'][k] for k in potential_plays}
        if sum(sub_order.values()) > 0:
            predicted = max(sub_order, key=sub_order.get)[-1]
        else:
            predicted = 'R'
        abbey_move = beats[predicted]
        guesses['abbey'] = beats[abbey_move]
    else:
        guesses['abbey'] = random.choice(['R', 'P', 'S'])

    # ---- Simulate mrugesh: counters most frequent of MY last 10 moves ----
    if my_history:
        last_ten = my_history[-10:]
        most_frequent = max(set(last_ten), key=last_ten.count)
        mrugesh_move = beats[most_frequent]
        guesses['mrugesh'] = beats[mrugesh_move]
    else:
        guesses['mrugesh'] = random.choice(['R', 'P', 'S'])

    # ---- Simulate quincy: fixed cycle R,R,P,P,S advancing once per round ----
    quincy_choices = ["R", "R", "P", "P", "S"]
    quincy_move = quincy_choices[state['round'] % len(quincy_choices)]
    guesses['quincy'] = beats[quincy_move]

    # ---- N-gram back-off predictor on the real opponent's history ----
    ngram_guess = None
    for k in range(n, 0, -1):
        if len(opponent_history) >= k:
            key = "".join(opponent_history[-k:])
            counts = state['ngram_patterns'].get(key)
            if counts and sum(counts.values()) >= 3:
                predicted = max(counts, key=counts.get)
                ngram_guess = beats[predicted]
                break
    if ngram_guess is None:
        if len(opponent_history) >= 3:
            last_few = opponent_history[-10:]
            most_common = max(set(last_few), key=last_few.count)
            ngram_guess = beats[most_common]
        elif opponent_history:
            ngram_guess = beats[opponent_history[-1]]
        else:
            ngram_guess = random.choice(['R', 'P', 'S'])
    guesses['ngram'] = ngram_guess

    # ---- Pick the strategy with the best recent track record ----
    if state['round'] <= 3:
        best_strategy = 'ngram'
    else:
        best_strategy = max(state['strategy_scores'], key=state['strategy_scores'].get)

    guess = guesses[best_strategy]

    state['strategy_last_guess'] = guesses

    my_history.append(guess)
    return guess
